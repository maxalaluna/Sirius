#!/bin/bash
file="$HOME/sirius/$1"
while read -r line; do
  name=`echo $line | awk '{ print $1 }'`
  port=`echo $line | awk '{ print $2 }'`
  ip=`echo $line | awk '{ print $3 }'`
  mac=`echo $line | awk '{ print $4 }'`
  echo "Configuring $name"
  echo "sudo ovs-docker-SUPERCLOUD add-port br1 eth2 $name --port=$port --ipaddress=$ip/16 --macaddress=$mac --mtu=1450" >> log.txt
  sudo ovs-docker-SUPERCLOUD add-port br1 eth2 $name --port=$port --ipaddress=$ip/16 --macaddress=$mac --mtu=1450 >> log.txt 2>&1
  echo >> log.txt
done < $file
