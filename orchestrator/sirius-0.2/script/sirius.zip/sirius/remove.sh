#!/bin/bash
file="$HOME/sirius/$1"
while read -r line; do
  name=`echo $line | awk '{ print $1 }'`
  echo "sudo ovs-docker-SUPERCLOUD del-port br1 eth2 $name" >> log.txt
  sudo ovs-docker-SUPERCLOUD del-port br1 eth2 $name >> log.txt 2>&1
  echo "docker stop -t 0 $name" >> log.txt
  docker stop -t 0 $name >> log.txt 2>&1
  echo "docker rm $name" >> log.txt
  docker rm $name >> log.txt 2>&1
  echo >> log.txt
done < $file
