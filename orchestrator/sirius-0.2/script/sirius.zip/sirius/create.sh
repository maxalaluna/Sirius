#!/bin/bash
file="$HOME/sirius/$1"
range=200
k=1
size=`wc -l < $file`
while [ $k -le $size ]; do
  max=$(($k + $range - 1))
  if [ $max -gt $size ]; then
    max=$size
  fi
  nb=`docker ps | wc -l`
  while [ $k -le $max ]; do
    read -r line
    name=`echo $line | awk '{ print $1 }'`
    image=`echo $line | awk '{ print $5 }'`
    echo "Creating $name with image $image"
    if [ "$image" = "ubuntu" ]; then
      echo "docker run -dit --name $name --hostname $name host bash" >> log.txt
      docker run -dit --name $name --hostname $name host bash >> log.txt 2>&1 &
    elif [ "$image" = "busybox" ]; then
      echo "docker run -dit --name $name progrium/busybox sh" >> log.txt
      docker run -dit --name $name progrium/busybox sh >> log.txt 2>&1 &
    elif [ "$image" = "master" ]; then
      docker run -itd -p 8181:8088 -p 8585:50070 --name $name --hostname hadoop-master --add-host="hadoop-master:10.0.0.1" --add-host="hadoop-slave1:10.0.0.2" --add-host="hadoop-slave2:10.0.0.3" --add-host="hadoop-slave3:10.0.0.4" --add-host="hadoop-slave4:10.0.0.5" --add-host="hadoop-slave5:10.0.0.6" --add-host="hadoop-slave6:10.0.0.7" --add-host="hadoop-slave7:10.0.0.8" --add-host="hadoop-slave8:10.0.0.9" --add-host="hadoop-slave9:10.0.0.10" kiwenlau/hadoop:1.0 >> log.txt 2>&1 &
    elif [ "$image" = "slave1" ]; then
      docker run -itd --name $name --hostname hadoop-slave1 --add-host="hadoop-master:10.0.0.1" --add-host="hadoop-slave1:10.0.0.2" --add-host="hadoop-slave2:10.0.0.3" --add-host="hadoop-slave3:10.0.0.4" --add-host="hadoop-slave4:10.0.0.5" --add-host="hadoop-slave5:10.0.0.6" --add-host="hadoop-slave6:10.0.0.7" --add-host="hadoop-slave7:10.0.0.8" --add-host="hadoop-slave8:10.0.0.9" --add-host="hadoop-slave9:10.0.0.10" kiwenlau/hadoop:1.0 >> log.txt 2>&1 &
    elif [ "$image" = "slave2" ]; then
      docker run -itd --name $name --hostname hadoop-slave2 --add-host="hadoop-master:10.0.0.1" --add-host="hadoop-slave1:10.0.0.2" --add-host="hadoop-slave2:10.0.0.3" --add-host="hadoop-slave3:10.0.0.4" --add-host="hadoop-slave4:10.0.0.5" --add-host="hadoop-slave5:10.0.0.6" --add-host="hadoop-slave6:10.0.0.7" --add-host="hadoop-slave7:10.0.0.8" --add-host="hadoop-slave8:10.0.0.9" --add-host="hadoop-slave9:10.0.0.10" kiwenlau/hadoop:1.0 >> log.txt 2>&1 &
    elif [ "$image" = "slave3" ]; then
      docker run -itd --name $name --hostname hadoop-slave3 --add-host="hadoop-master:10.0.0.1" --add-host="hadoop-slave1:10.0.0.2" --add-host="hadoop-slave2:10.0.0.3" --add-host="hadoop-slave3:10.0.0.4" --add-host="hadoop-slave4:10.0.0.5" --add-host="hadoop-slave5:10.0.0.6" --add-host="hadoop-slave6:10.0.0.7" --add-host="hadoop-slave7:10.0.0.8" --add-host="hadoop-slave8:10.0.0.9" --add-host="hadoop-slave9:10.0.0.10" kiwenlau/hadoop:1.0 >> log.txt 2>&1 &
    elif [ "$image" = "slave4" ]; then
      docker run -itd --name $name --hostname hadoop-slave4 --add-host="hadoop-master:10.0.0.1" --add-host="hadoop-slave1:10.0.0.2" --add-host="hadoop-slave2:10.0.0.3" --add-host="hadoop-slave3:10.0.0.4" --add-host="hadoop-slave4:10.0.0.5" --add-host="hadoop-slave5:10.0.0.6" --add-host="hadoop-slave6:10.0.0.7" --add-host="hadoop-slave7:10.0.0.8" --add-host="hadoop-slave8:10.0.0.9" --add-host="hadoop-slave9:10.0.0.10" kiwenlau/hadoop:1.0 >> log.txt 2>&1 &
    elif [ "$image" = "slave5" ]; then
      docker run -itd --name $name --hostname hadoop-slave5 --add-host="hadoop-master:10.0.0.1" --add-host="hadoop-slave1:10.0.0.2" --add-host="hadoop-slave2:10.0.0.3" --add-host="hadoop-slave3:10.0.0.4" --add-host="hadoop-slave4:10.0.0.5" --add-host="hadoop-slave5:10.0.0.6" --add-host="hadoop-slave6:10.0.0.7" --add-host="hadoop-slave7:10.0.0.8" --add-host="hadoop-slave8:10.0.0.9" --add-host="hadoop-slave9:10.0.0.10" kiwenlau/hadoop:1.0 >> log.txt 2>&1 &
    elif [ "$image" = "slave6" ]; then
      docker run -itd --name $name --hostname hadoop-slave6 --add-host="hadoop-master:10.0.0.1" --add-host="hadoop-slave1:10.0.0.2" --add-host="hadoop-slave2:10.0.0.3" --add-host="hadoop-slave3:10.0.0.4" --add-host="hadoop-slave4:10.0.0.5" --add-host="hadoop-slave5:10.0.0.6" --add-host="hadoop-slave6:10.0.0.7" --add-host="hadoop-slave7:10.0.0.8" --add-host="hadoop-slave8:10.0.0.9" --add-host="hadoop-slave9:10.0.0.10" kiwenlau/hadoop:1.0 >> log.txt 2>&1 &
    elif [ "$image" = "slave7" ]; then
      docker run -itd --name $name --hostname hadoop-slave7 --add-host="hadoop-master:10.0.0.1" --add-host="hadoop-slave1:10.0.0.2" --add-host="hadoop-slave2:10.0.0.3" --add-host="hadoop-slave3:10.0.0.4" --add-host="hadoop-slave4:10.0.0.5" --add-host="hadoop-slave5:10.0.0.6" --add-host="hadoop-slave6:10.0.0.7" --add-host="hadoop-slave7:10.0.0.8" --add-host="hadoop-slave8:10.0.0.9" --add-host="hadoop-slave9:10.0.0.10" kiwenlau/hadoop:1.0 >> log.txt 2>&1 &
    elif [ "$image" = "slave8" ]; then
      docker run -itd --name $name --hostname hadoop-slave8 --add-host="hadoop-master:10.0.0.1" --add-host="hadoop-slave1:10.0.0.2" --add-host="hadoop-slave2:10.0.0.3" --add-host="hadoop-slave3:10.0.0.4" --add-host="hadoop-slave4:10.0.0.5" --add-host="hadoop-slave5:10.0.0.6" --add-host="hadoop-slave6:10.0.0.7" --add-host="hadoop-slave7:10.0.0.8" --add-host="hadoop-slave8:10.0.0.9" --add-host="hadoop-slave9:10.0.0.10" kiwenlau/hadoop:1.0 >> log.txt 2>&1 &
    elif [ "$image" = "slave9" ]; then
      docker run -itd --name $name --hostname hadoop-slave9 --add-host="hadoop-master:10.0.0.1" --add-host="hadoop-slave1:10.0.0.2" --add-host="hadoop-slave2:10.0.0.3" --add-host="hadoop-slave3:10.0.0.4" --add-host="hadoop-slave4:10.0.0.5" --add-host="hadoop-slave5:10.0.0.6" --add-host="hadoop-slave6:10.0.0.7" --add-host="hadoop-slave7:10.0.0.8" --add-host="hadoop-slave8:10.0.0.9" --add-host="hadoop-slave9:10.0.0.10" kiwenlau/hadoop:1.0 >> log.txt 2>&1 &
    else
      echo "unknown image '$image'" >> log.txt
    fi
    echo >> log.txt
    nb=$(($nb + 1))
    k=$(($k + 1))
  done
  cur=`docker ps | wc -l`
  while [ $cur -lt $nb ]; do
    echo "Waiting for completion"
    sleep 1
    cur=`docker ps | wc -l`
  done
done < $file
